-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 03, 2016 at 03:35 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `netchat`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(50) NOT NULL,
  `1st_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `number` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `1st_name`, `last_name`, `username`, `password`, `number`) VALUES
(1, 'Tipu', 'Sultan', 'tsr', '1234', '01990718798'),
(2, 'Ananna', 'Sultana', 'anu', '1234', '01843783848'),
(3, 'Farzia', 'Mou', 'mou', '1234', '01682245777'),
(4, 'Rubaya', 'Nishi', 'nishi', '1234', '01799746094'),
(5, 'Rabeya', 'Afnim', 'rabeya', '1234', '01676262350');

-- --------------------------------------------------------

--
-- Table structure for table `message_history`
--

CREATE TABLE `message_history` (
  `ID` int(12) NOT NULL,
  `message` varchar(10000) NOT NULL,
  `new_massege` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `message_history`
--

INSERT INTO `message_history` (`ID`, `message`, `new_massege`) VALUES
(1, 'Hi There\n\rTipu: Hi! How are you?\n\rTipu: Is there anyone?\n\rRabeya: Yes... How r u?\n\rTipu: Fine U?\n\rRabeya: Also..\n\rRabeya: Whats About the other?\n\rFarzia: Hi!\n\rAnanna: hello!\n\rRubaya: Everyone is here, no tension..', 'Rubaya: Everyone is here, no tension..');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
