package NetChatApplication;
import java.sql.*;
import javax.swing.*;

public class DBconnect {

	private static Connection con;
	
	public static Connection DBconnection(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/netchat","root","");
			return con;
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
			return null;
		}
		
	}
}
