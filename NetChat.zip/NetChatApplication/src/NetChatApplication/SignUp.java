package NetChatApplication;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.sql.*;
import java.sql.PreparedStatement;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class SignUp extends JFrame {

	private JPanel contentPane;
	private JTextField txtFirstname;
	private JTextField txtLastname;
	private JTextField txtUsername;
	private JButton btnNewButton;
	private JLabel lblFirstName;
	private JLabel lblLastName;
	private JLabel lblUsername;
	private JLabel lblPassword;
	
	private Connection connection=null;
	private JPasswordField passwordField;
	private JLabel label;
	private JTextField txtNumber;
	private String firstname ;

	public SignUp() {
		setForeground(new Color(0, 0, 0));
		connection = DBconnect.DBconnection();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 435, 505);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblRegistration = new JLabel("Registration");
		lblRegistration.setFont(new Font("Sitka Text", Font.BOLD | Font.ITALIC, 20));
		lblRegistration.setForeground(new Color(204, 255, 255));
		lblRegistration.setBounds(165, 21, 122, 23);
		contentPane.add(lblRegistration);
		
		txtFirstname = new JTextField();
		txtFirstname.setBounds(246, 67, 146, 26);
		contentPane.add(txtFirstname);
		txtFirstname.setColumns(10);
		
		txtLastname = new JTextField();
		txtLastname.setColumns(10);
		txtLastname.setBounds(246, 122, 146, 26);
		contentPane.add(txtLastname);
		
		txtUsername = new JTextField();
		txtUsername.setBounds(246, 179, 146, 26);
		contentPane.add(txtUsername);
		txtUsername.setColumns(10);
		
		btnNewButton = new JButton("Sign Up");
		btnNewButton.setForeground(new Color(0, 0, 153));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String query = "insert into login (1st_name,last_name,username,password,number) values (?,?,?,?,?) ";
					PreparedStatement pst = connection.prepareStatement(query);
					
					firstname = txtFirstname.getText();
					if(firstname.equals("")){
						JOptionPane.showMessageDialog(null, "Firstname Cannot be Empty!");
						return;
					}
					else{
						pst.setString(1, txtFirstname.getText());
					}
					
					String laststname = txtLastname.getText();
					if(laststname.equals("")){
						JOptionPane.showMessageDialog(null, "Lastname Cannot be Empty!");
						return;
					}
					else{
						pst.setString(2, txtLastname.getText());
					}
					
					String username = txtUsername.getText();
					if(username.equals("")){
						JOptionPane.showMessageDialog(null, "Username Cannot be Empty!");
						return;
					}
					else{
						int count=0;
						String query1 = "select * from login where username=?";
						PreparedStatement pst1 = connection.prepareStatement(query1);
						pst1.setString(1, username);
						ResultSet rs = pst1.executeQuery();
						while(rs.next()){
							count++;
						}
						pst1.close();
						rs.close();
						if(count>0){
							JOptionPane.showMessageDialog(null, "Username already exist! Try another Username!");
							return;
						}
						else{
						pst.setString(3, txtUsername.getText());
						}
					}
					
					
					String password = passwordField.getText();
					if(password.equals("")){
						JOptionPane.showMessageDialog(null, "Password Cannot be Empty!");
						return;
					}
					else{
						pst.setString(4, passwordField.getText());
					}
					
					String number = txtNumber.getText();
					if(number.equals("")){
						JOptionPane.showMessageDialog(null, "Number Cannot be Empty!");
						return;
					}
					else{
						int count=0;
						String query1 = "select * from login where number=?";
						PreparedStatement pst1 = connection.prepareStatement(query1);
						pst1.setString(1, number);
						ResultSet rs = pst1.executeQuery();
						while(rs.next()){
							count++;
						}
						pst1.close();
						rs.close();
						if(count>0){
							JOptionPane.showMessageDialog(null, "Number already exist!");
							return;
						}
						else{
						pst.setString(5, txtNumber.getText());
						}
					}
					
					
					pst.execute();
					JOptionPane.showMessageDialog(null, "Successfully Register!!");
					pst.close();
					dispose();
					new MainPage(username,firstname );
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
		});
		btnNewButton.setFont(new Font("Sitka Text", Font.BOLD | Font.ITALIC, 12));
		btnNewButton.setBounds(165, 374, 89, 34);
		contentPane.add(btnNewButton);
		
		lblFirstName = new JLabel("First Name:");
		lblFirstName.setForeground(new Color(204, 255, 255));
		lblFirstName.setFont(new Font("Sitka Small", Font.BOLD | Font.ITALIC, 13));
		lblFirstName.setBounds(53, 70, 137, 28);
		contentPane.add(lblFirstName);
		
		lblLastName = new JLabel("Last Name:");
		lblLastName.setForeground(new Color(204, 255, 255));
		lblLastName.setFont(new Font("Sitka Small", Font.BOLD | Font.ITALIC, 13));
		lblLastName.setBounds(53, 125, 137, 31);
		contentPane.add(lblLastName);
		
		lblUsername = new JLabel("Username:");
		lblUsername.setForeground(new Color(204, 255, 255));
		lblUsername.setFont(new Font("Sitka Small", Font.BOLD | Font.ITALIC, 13));
		lblUsername.setBounds(53, 181, 137, 31);
		contentPane.add(lblUsername);
		
		lblPassword = new JLabel("Password:");
		lblPassword.setForeground(new Color(204, 255, 255));
		lblPassword.setFont(new Font("Sitka Small", Font.BOLD | Font.ITALIC, 13));
		lblPassword.setBounds(53, 239, 137, 31);
		contentPane.add(lblPassword);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(246, 244, 146, 26);
		contentPane.add(passwordField);
		
		JLabel lblNumber = new JLabel("Number:");
		lblNumber.setForeground(new Color(204, 255, 255));
		lblNumber.setFont(new Font("Sitka Small", Font.BOLD | Font.ITALIC, 13));
		lblNumber.setBounds(53, 297, 137, 31);
		contentPane.add(lblNumber);
		
		txtNumber = new JTextField();
		txtNumber.setColumns(10);
		txtNumber.setBounds(246, 302, 146, 26);
		contentPane.add(txtNumber);
		
		label = new JLabel("");
		label.setForeground(new Color(204, 255, 255));
		label.setIcon(new ImageIcon("F:\\java neao\\NetChatApplication\\img\\A65u5lO-fireflies-wallpaper.png"));
		label.setBounds(0, 0, 419, 466);
		contentPane.add(label);
		setVisible(true);
	}
}
