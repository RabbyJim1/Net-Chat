package NetChatApplication;
import java.awt.EventQueue;
import java.sql.*;
import javax.swing.*;

import java.awt.Font;
import java.awt.Image;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;
import java.awt.Window.Type;

public class Login {

	private JFrame frmLogin;

	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login();
					window.frmLogin.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	Connection connection = null;
	private JTextField Username;
	private JPasswordField passwordField;
	private String name;
	private JLabel label;
	private JLabel lblNewLabel;
	private String username;
	private String password;
	private String n;
	public Login() {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
			e.printStackTrace();
		} 
		initialize();
		connection = DBconnect.DBconnection();
	}

	
	private void initialize() {
		frmLogin = new JFrame();
		frmLogin.setForeground(new Color(0, 0, 102));
		frmLogin.setIconImage(Toolkit.getDefaultToolkit().getImage("F:\\java neao\\NetChatApplication\\img\\photo.png"));
		frmLogin.setBackground(new Color(0, 0, 0));
		frmLogin.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		frmLogin.setTitle("Login");
		frmLogin.setBounds(100, 100, 412, 537);
		frmLogin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmLogin.getContentPane().setLayout(null);
		
		JLabel lblWelcome = new JLabel("Welcome");
		lblWelcome.setForeground(new Color(204, 255, 255));
		lblWelcome.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 30));
		lblWelcome.setBounds(126, 11, 118, 77);
		frmLogin.getContentPane().add(lblWelcome);
		
		Username = new JTextField();
		Username.setToolTipText("");
		Username.setBounds(195, 123, 163, 32);
		frmLogin.getContentPane().add(Username);
		Username.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setToolTipText("");
		passwordField.setBounds(195, 198, 163, 32);
		frmLogin.getContentPane().add(passwordField);
		
		
		
		JButton Loginbtn = new JButton("Login");
		Loginbtn.setFont(new Font("Sitka Text", Font.BOLD, 12));
		Loginbtn.setBackground(new Color(153, 255, 153));
		Loginbtn.setForeground(new Color(51, 0, 153));
		Loginbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					
					username = Username.getText();
					password = passwordField.getText();
					String query = "select * from login where username=? and password=?";
					PreparedStatement pst = connection.prepareStatement(query);
					pst.setString(1, username);
					pst.setString(2, password);
					
					ResultSet rs = pst.executeQuery();
					int count=0;
					while(rs.next()){
						count++;
						n= rs.getString("1st_name");
					}
					
					if(count  == 1){
						JOptionPane.showMessageDialog(null, "Username and Password Correct!!!");
						exit();
					}
					
					else{
						JOptionPane.showMessageDialog(null, "Username and Password is not Correct!!!");
					}
					
					rs.close();
					pst.close();
					
				} catch (Exception e) {
					JOptionPane.showMessageDialog(null, e);
				}
			}
		});
		Loginbtn.setBounds(143, 277, 110, 32);
		frmLogin.getContentPane().add(Loginbtn);
		
		
		JButton btnSignUp = new JButton("Registration");
		btnSignUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frmLogin.dispose();
				new SignUp();
			}
		});
		btnSignUp.setFont(new Font("Sitka Text", Font.BOLD, 12));
		btnSignUp.setBackground(new Color(153, 255, 153));
		btnSignUp.setForeground(new Color(51, 0, 153));
		btnSignUp.setBounds(143, 349, 110, 32);
		frmLogin.getContentPane().add(btnSignUp);
		
		JLabel lblPassword = new JLabel("Password:");
		lblPassword.setForeground(new Color(204, 255, 255));
		lblPassword.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblPassword.setBounds(27, 195, 89, 37);
		frmLogin.getContentPane().add(lblPassword);
		
		JLabel lblUsername = new JLabel("Username:");
		lblUsername.setForeground(new Color(204, 255, 255));
		lblUsername.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblUsername.setBounds(27, 123, 89, 37);
		frmLogin.getContentPane().add(lblUsername);
		
	
		lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("F:\\java neao\\NetChatApplication\\img\\A65u5lO-fireflies-wallpaper.png"));
		lblNewLabel.setBounds(0, 0, 395, 498);
		frmLogin.getContentPane().add(lblNewLabel);
		
		
	}
	
	private void exit(){
		frmLogin.dispose();
		new MainPage(username,n);
	}
}
