package NetChatApplication;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JTextField;

public class MainPage extends JFrame {

	private JPanel contentPane;
	private String username;
	private int Notification=0;
	private String N;
	
	Connection connection = null;
	

	public MainPage(String username,String s) {
		setTitle("Welcome "+s+"!!!");
		
		connection = DBconnect.DBconnection();
		
		
		
		setBackground(Color.DARK_GRAY);
		this.username = username;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 412, 537);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton_1 = new JButton("Message");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new ChatBox(username,s);
			}
		});
		btnNewButton_1.setBounds(153, 237, 89, 23);
		contentPane.add(btnNewButton_1);
		
		JLabel lblName = new JLabel("           Welcome "+s);
		lblName.setFont(new Font("Sitka Text", Font.BOLD, 24));
		lblName.setForeground(new Color(0, 204, 255));
		lblName.setBounds(44, 35, 308, 76);
		contentPane.add(lblName);
		
		
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon("F:\\java neao\\NetChatApplication\\img\\A65u5lO-fireflies-wallpaper.png"));
		label.setBounds(0, 0, 396, 498);
		contentPane.add(label);
		setVisible(true);
	}
}
