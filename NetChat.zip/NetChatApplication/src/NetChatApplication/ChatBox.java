package NetChatApplication;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.*;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class ChatBox extends JFrame {

	private JPanel contentPane;
	private String username;
	private JTextField txtMassege;
	private JTextArea txtrHistory;
	private String message;
	private String prvmassege;
	private String message2;
	private String s;
	private String x ;
	JLabel label = new JLabel();
	JScrollPane  scrollc = new JScrollPane();

    Connection connection = null;
    private JButton btnSend;


	public ChatBox(String username,String n) {
		s=n;
		connection = DBconnect.DBconnection();
		this.username = username;
		cerateBox();
		try {
			String qurey = "select * from message_history where ID=?";
			PreparedStatement pst = connection.prepareStatement(qurey);
			pst.setInt(1, 1);
			ResultSet rs = pst.executeQuery();
			while(rs.next()){
			    message2 = rs.getString("message");
			}
			
			txtrHistory.append(message2);
			
			pst.close();
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	private void cerateBox(){
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 716, 454);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		
		
		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{633, 65, 0};
		gbl_contentPane.rowHeights = new int[]{384, 26, 0};
		gbl_contentPane.columnWeights = new double[]{0.0, 0.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{0.0, 0.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		txtrHistory = new JTextArea();
		txtrHistory.setEditable(false);
		JScrollPane scroll = new JScrollPane(txtrHistory);
		GridBagConstraints gbc_txtrHistory = new GridBagConstraints();
		gbc_txtrHistory.fill = GridBagConstraints.BOTH;
		gbc_txtrHistory.insets = new Insets(0, 0, 5, 0);
		gbc_txtrHistory.gridwidth = 2;
		gbc_txtrHistory.gridx = 0;
		gbc_txtrHistory.gridy = 0;
		contentPane.add(scroll, gbc_txtrHistory);
		
		txtMassege = new JTextField();
		txtMassege.addKeyListener(new KeyAdapter() {
				public void keyPressed(KeyEvent e) {
					if(e.getKeyCode()==KeyEvent.VK_ENTER){
						
						send();
					}
			}
		});
		GridBagConstraints gbc_txtMassege = new GridBagConstraints();
		gbc_txtMassege.fill = GridBagConstraints.BOTH;
		gbc_txtMassege.insets = new Insets(0, 0, 0, 5);
		gbc_txtMassege.gridx = 0;
		gbc_txtMassege.gridy = 1;
		contentPane.add(txtMassege, gbc_txtMassege);
		txtMassege.setColumns(10);
		
		btnSend = new JButton("Send");
		btnSend.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				send();
			}
		});
		GridBagConstraints gbc_btnSend = new GridBagConstraints();
		gbc_btnSend.fill = GridBagConstraints.VERTICAL;
		gbc_btnSend.gridx = 1;
		gbc_btnSend.gridy = 1;
		contentPane.add(btnSend, gbc_btnSend);
		setVisible(true);
	}
	

private void send(){
	
prvmassege =s+": "+ txtMassege.getText();
		if(prvmassege.equals(""))return;
		
		try {
			String qurey = "select * from message_history where ID=?";
			PreparedStatement pst = connection.prepareStatement(qurey);
			pst.setInt(1, 1);
			ResultSet rs = pst.executeQuery();
			while(rs.next()){
				String qurey1 = "update message_history SET new_massege='"+prvmassege+"'";
				PreparedStatement pst1= connection.prepareStatement(qurey1);
				pst1= connection.prepareStatement(qurey1);
				pst1.execute();
				pst1.close();
			}
			pst.close();
			rs.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		txtMassege.setText("");
		
		
		try {
			String qurey = "select * from message_history where ID=?";
			PreparedStatement pst = connection.prepareStatement(qurey);
			pst.setInt(1, 1);
			ResultSet rs = pst.executeQuery();
			while(rs.next()){
				message = rs.getString("message");
				message = message +"\n\r";
			}
			
			pst.close();
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		console();
		txtMassege.requestFocusInWindow();
}
	
	private void console(){
		
		
try {
			
			String qurey = "select * from message_history where ID=?";
			PreparedStatement pst = connection.prepareStatement(qurey);
			pst.setInt(1, 1);
			ResultSet rs = pst.executeQuery();
			while(rs.next()){
				 x = rs.getString("new_massege");
			}
			pst.close();
			rs.close();
			
			if(!prvmassege.equals(x)){
				txtrHistory.append(x+"\n\r");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		txtrHistory.append("\n"+prvmassege);
		
		
		try {
			String qurey = "select * from message_history where ID=?";
			PreparedStatement pst = connection.prepareStatement(qurey);
			pst.setInt(1, 1);
			ResultSet rs = pst.executeQuery();
			while(rs.next()){
				String b = message+""+prvmassege;
				String qurey1 = "update message_history SET message='"+b+"'";
				PreparedStatement pst1= connection.prepareStatement(qurey1);
				pst1= connection.prepareStatement(qurey1);
				pst1.execute();
				pst1.close();
			}
			pst.close();
			rs.close();
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		
		
	}
	
	
}
